import pygame
import random

BLACK = (0, 0, 0)
WINDOW_WIDTH = 500
WINDOW_HEIGHT = 500

class Bomb:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.is_exploded = False
        self.image = pygame.image.load("bomb.png")
        self.explosion_image = pygame.image.load("explosion.png")
    
    def draw(self, surface):
        if self.is_exploded:
            explosion_rect = self.explosion_image.get_rect(center=(self.x, self.y))
            surface.blit(self.explosion_image, explosion_rect)
        else:
            bomb_rect = self.image.get_rect(center=(self.x, self.y))
            surface.blit(self.image, bomb_rect)
    
    def handle_click(self, click_pos):
        bomb_rect = self.image.get_rect(center=(self.x, self.y))
        if bomb_rect.collidepoint(click_pos):
            self.is_exploded = True

pygame.init()
window_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Bomb Game')
bombs = []
for _ in range(20):
    x = random.randint(0, WINDOW_WIDTH)
    y = random.randint(0, WINDOW_HEIGHT)
    bombs.append(Bomb(x, y))
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONUP:
            click_pos = pygame.mouse.get_pos()
            for bomb in bombs:
                bomb.handle_click(click_pos)
    window_surface.fill(BLACK)
    for bomb in bombs:
        bomb.draw(window_surface)
    pygame.display.flip()
    clock.tick(60)
pygame.quit()